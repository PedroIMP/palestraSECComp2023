# Este programa lê um número natural n e calcula
# a soma dos valores 0, 1, 2, ..., n - 1

def soma(n):
    s = 0

    for i in range(n):
        s = s + i

    return s


def ler_numero():
    while True:
        try:
            valor = int(input('n: '))
        except ValueError:
            print('Número inválido')
        else:
            break

    return valor


limite = ler_numero()

while limite != 0:
    resultado = soma(limite)
    print('A soma de 0 até', limite - 1, 'é', resultado)
    limite = ler_numero()

print('Tchau')


# Este programa sorteia um número entre 1 e 100 e repetidamente lê um input do
# usuário até que o valor lido seja igual ao número sorteado.

import random

numero = random.randint(1, 100)

palpite = int(input('Qual é seu palpite? '))

while numero != palpite:
    if numero > palpite:
        print('Errou! O número é maior que', palpite)
    else:
        print('Errou! O número é menor que', palpite)

    palpite = int(input('Qual é seu novo palpite? '))

print('Parabéns! Você acertou')

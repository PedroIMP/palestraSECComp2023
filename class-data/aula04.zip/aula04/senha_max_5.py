senha_secreta = '1234'

for i in range(5):
    senha = input('Digite a senha: ')

    if senha == '':
        print('Senha vazia!')
        continue

    if senha != senha_secreta:
        print('Senha errada!')
        continue

    break


if senha == senha_secreta:
    # Se senha é igual a senha_correta, então sabemos que o break foi executado
    # e o "for" parou antes das tentativas serem esgotadas
    print('Senha correta! Bem-vindo ao sistema.')
else:
    # Se senha é diferente de senha_correta, então sabemos que todas as 5
    # iterações do "for" foram executadas
    print('Limite de tentativas esgotado.')

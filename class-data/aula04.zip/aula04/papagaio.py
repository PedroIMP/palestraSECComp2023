# Ler e repetir ("remendar") o que o usuário disse até ele dizer tchau

print('Olá! Eu sou um papagaio')

while True:
    frase = input('Usuario: ')

    if frase.lower() == 'tchau':
        break

    print('Papagaio:', frase)

print('Programa finalizado')

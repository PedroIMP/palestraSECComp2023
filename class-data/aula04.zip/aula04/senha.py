senha_secreta = '1234'

while True:
    senha = input('Digite a senha: ')

    if senha == '':
        print('Senha vazia!')
        continue

    if senha != senha_secreta:
        print('Senha errada!')
        continue

    print('Senha correta! Bem-vindo ao sistema.')
    break

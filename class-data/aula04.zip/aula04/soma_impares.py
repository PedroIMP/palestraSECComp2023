n = 10

soma = 0
for i in range(n):
    if i % 2 == 0:
        continue
    soma += i

print(soma)


soma = 0
for i in range(1, n, 2):
    soma += i
print(soma)

def potencia(base, expoente):
    try:
        base = float(base)
        expoente = float(expoente)
        resultado = base ** expoente
    except ValueError:
        print('Algum dos argumentos não é um número válido')
    except OverflowError:
        print('O resultado é muito grande')
    else:
        print(base, 'elevado a', expoente, 'é', resultado)


potencia('três', '3')
potencia('3', '3')
potencia('2.4', '1000')

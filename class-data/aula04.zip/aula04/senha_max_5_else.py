senha_secreta = '1234'

for i in range(5):
    senha = input('Digite a senha: ')

    if senha == '':
        print('Senha vazia!')
        continue

    if senha != senha_secreta:
        print('Senha errada!')
        continue

    print('Senha correta! Bem-vindo ao sistema.')
    break
else:
    # Esse bloco é executado caso break não tenha sido executado, o que
    # significa que todos os items do iterável range(5) foram "consumidos".
    print('Limite de tentativas esgotado.')

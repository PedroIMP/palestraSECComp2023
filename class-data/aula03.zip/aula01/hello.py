nome = input('Qual é seu nome? ')

if nome:
    print('Olá,', nome)
else:
    print('Você passou um nome vazio!')
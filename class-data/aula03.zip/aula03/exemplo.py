print('Olá, Gustavo')

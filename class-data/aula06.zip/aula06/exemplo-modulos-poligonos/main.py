import poligonos

q = poligonos.quadrado(0, 0, 20)
print('q:', q)
print('perímetro de q:', poligonos.perimetro(q))

r = poligonos.retangulo(12, -50, 60, 20)
print('r:', r)
print('perímetro de r:', poligonos.perimetro(r))

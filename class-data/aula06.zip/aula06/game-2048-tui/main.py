import tui_mode


if __name__ == '__main__':
    tui_mode.run()
